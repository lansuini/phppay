package demo;

public class PayApiDemo {

    public static void main(String[] args) {
        //需要依赖 springframework.web进行Http请求（或者换自己Http的请求方式）
        //依赖commons包 进行Md5计算(或者自己实现相关代码)
        //依赖FastJson（或者自己更改json解析部分）

        // 网关地址
        String gateway = "http://gate.ddzf03.com";
        // 商户号
        String merchantNo = "10000162";
        //密钥
        String signKey = "28843427543dfa7d364566c3d321900a";


        final DaDongPay daDongPay = new DaDongPay(gateway, merchantNo, signKey);

        /**
         * 下面注释打开进行调试
         */
        //支付下单
//        daDongPay.pay();

        //支付回调
//        String notifyJson = HttpUtil.mockReturnVerify();
//        daDongPay.returnVerify(notifyJson);

//        //查单
//        daDongPay.query();

        //代付
//        daDongPay.daifu();
    }


}
