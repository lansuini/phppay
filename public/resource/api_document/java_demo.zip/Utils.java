package demo;

import org.apache.commons.lang.StringUtils;

import java.util.*;

public class Utils {

    /**
     * 根据map的key进行字典升序排序
     *
     * @param map
     * @return
     */
    public static Map<String, Object> sortMapByKey(Map<String, Object> map) {
        Map<String, Object> treemap = new TreeMap<String, Object>(map);
        List<Map.Entry<String, Object>> list = new ArrayList<Map.Entry<String, Object>>(treemap.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Object>>() {
            public int compare(Map.Entry<String, Object> o1, Map.Entry<String, Object> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        });
        return treemap;
    }

    /**
     * 删除空值字段
     *
     * @param map
     */
    public static void removeNullValue(Map<String, Object> map) {
        Set set = map.keySet();
        final Iterator iterator = set.iterator();
        while (iterator.hasNext()) {
            final String key = (String) iterator.next();
            final Object value = map.get(key);
            //删除空值字段
            if (value == null) {
                iterator.remove();
            } else {
                if (value instanceof String) {
                    if (((String) value).trim().length() == 0) {
                        iterator.remove();
                    }
                }
            }
        }
    }

    /**
     * 将map转换成url参数
     *
     * @param map
     * @return
     */
    public static String getUrlParamsByMap(Map<String, Object> map) {
        if (map == null) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        try {
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                sb.append(entry.getKey() + "=" + entry.getValue());
                sb.append("&");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        String s = sb.toString();
        if (s.endsWith("&")) {
            s = StringUtils.substringBeforeLast(s, "&");
        }
        return s;
    }
}
