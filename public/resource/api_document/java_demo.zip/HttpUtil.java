package demo;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

public class HttpUtil {
    public static String doHttpPost(String gateway, String path, Map<String, Object> params) {
        String url = gateway + path;
        System.out.println("请求地址:" + url);
        System.out.println("请求参数:" + Utils.getUrlParamsByMap(params));

        final RestTemplate restTemplate = new RestTemplate();
        final MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        params.forEach(map::add);
        final String json = restTemplate.postForObject(url, map, String.class);
        System.out.println("请求响应JSON:" + json);
        return json;
    }

    public static String mockReturnVerify() {
        //以实际数据为准
        return "{\"code\":\"SUCCESS\",\"msg\":\"成功\",\"sign\":\"654a41f556d2aa5d0fb3d04267988566\",\"biz\":{\"merchantNo\":\"商户号\",\"merchantOrderNo\":\"商户订单号\",\"platformOrderNo\":\"平台订单号\",\"orderStatus\":\"Success\",\"payTime\":\"20200119210304\"}}";
    }
}
