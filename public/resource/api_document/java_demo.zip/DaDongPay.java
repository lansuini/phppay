package demo;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 大栋支付部分示例
 * 未仔细调试，只确保签名部分没问题，实际使用请结合文档
 */
public class DaDongPay {
    public static final String PAY_PATH = "/paygateway/order";
    public static final String QUERY_PATH = "/paygateway/queryPayOrder";
    public static final String DAIFU_PATH = "/paygateway/settlement";

    private final String gateway;
    private final String merchantNo;
    private final String signKey;

    public DaDongPay(String gateway, String merchantNo, String signKey) {
        this.gateway = gateway;
        this.merchantNo = merchantNo;
        this.signKey = signKey;
    }

    /**
     * 支付下单
     */
    public void pay() {
        //订单号(由商户业务自主实现，保证唯一)
        String orderNumber = System.currentTimeMillis() + "";
        String payType = "OnlineAlipayH5";
        String notifyUrl = "http://mockmerchant.wldev01.com/merchant/success";

        Map<String, Object> params = new HashMap<>();
        params.put("merchantNo", merchantNo);//商户号
        params.put("merchantOrderNo", orderNumber);//订单号
        params.put("merchantReqTime", getCurrentTimeWithFormat());//当前下单时间
        params.put("orderAmount", 500);//下单金额
        params.put("tradeSummary", "我是摘要");
        params.put("payModel", "Direct");//直连模式
        params.put("payType", payType);//通道类型
        params.put("cardType", "DEBIT");
        params.put("userTerminal", "Phone");
        params.put("userIp", "159.138.86.177");//下单用户ip
        params.put("backNoticeUrl", notifyUrl);//通知结果地址

        //生成签名
        params.put("sign", getSign(params));

        //http请求并获取返回内容
        String response = HttpUtil.doHttpPost(gateway, PAY_PATH, params);
        final JSONObject objects = JSONObject.parseObject(response);

        if (objects == null) {
            System.out.println("下单失败");
            return;
        }

        try {
            final String payUrl = objects.getJSONObject("biz").getString("payUrl");
            System.out.println("支付地址:" + payUrl);
        } catch (Exception e) {
            String msg = objects.containsKey("msg") ? "下单失败:" + objects.getString("msg") : "下单失败";
            System.out.println(msg);
        }
    }

    /**
     * 支付回调验签
     */
    public void returnVerify(String json) {
        final JSONObject objects = JSONObject.parseObject(json);
        if (objects == null || !objects.containsKey("biz")) {
            //忽略
            return;
        }

        //取得验签业务参数
        final JSONObject bizObj = objects.getJSONObject("biz");

        //确定订单是成功支付才能往下进行
        if (bizObj.containsKey("orderStatus")) {
            if (!bizObj.getString("orderStatus").equals("Success")) {
                System.out.println("订单支付状态未完成");
                return;
            }
        }

        try {
            String returnSign = objects.getString("sign");
            final Map<String, Object> bizMap = bizObj.getInnerMap();

            final String sign = getSign(bizMap);
            //生成的sign与回调的sign对比，一致才可进行后面的上分处理
            if (!returnSign.equals(sign)) {
                System.out.println("验签失败");
                return;
            }
            //上分
            System.out.println("验签成功，上分");
            System.out.println("金额:" + bizMap.get("orderAmount"));
            System.out.println("订单:" + bizMap.get("merchantOrderNo"));
            System.out.println("支付平台订单:" + bizMap.get("platformOrderNo"));
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("验签异常，所有参数请记录数据库，以便查明原因");
        }

    }

    /**
     * 支付查单
     */
    public void query() {
        String orderNumber = UUID.randomUUID().toString();
        Map<String, Object> params = new HashMap<>();
        params.put("merchantNo", merchantNo);//商户号
        params.put("merchantOrderNo", orderNumber);//商户订单号
        params.put("sign", getSign(params));

        //http请求并获取返回内容
        String response = HttpUtil.doHttpPost(gateway, QUERY_PATH, params);
        final JSONObject objects = JSONObject.parseObject(response);
        if (objects == null || !objects.containsKey("biz")) {
            String msg = "查单失败";
            if (objects != null) {
                msg = objects.containsKey("msg") ? "查单失败:" + objects.getString("msg") : "查单失败";
            }
            System.out.println(msg);
            return;
        }

        final JSONObject bizObj = objects.getJSONObject("biz");
        final Map<String, Object> map = bizObj.getInnerMap();
        if ("Success".equals(map.get("orderStatus"))) {
            System.out.println("订单已支付");
        }
    }


    /**
     * 代付下单
     */
    public void daifu() {
        //订单号(由商户业务自主实现，保证唯一)
        String orderNumber = System.currentTimeMillis() + "";
        String notifyUrl = "http://mockmerchant.wldev01.com/merchant/success";

        Map<String, Object> params = new HashMap<>();
        params.put("merchantNo", merchantNo);//商户号
        params.put("merchantOrderNo", orderNumber);//订单号
        params.put("merchantReqTime", getCurrentTimeWithFormat());//当前下单时间
        params.put("orderAmount", 500);//下单金额
        params.put("tradeSummary", "我是摘要");
        params.put("bankAccountNo", "13188881111");//收款人卡号(支付宝则填支付宝账号)
        params.put("bankAccountName", "张三");//持卡人姓名(支付宝填真实全名)
        params.put("province", "广东");//开户行所属省
        params.put("city", "深圳");//开户行所属市
        params.put("bankName", "ICBC");//bankName
        params.put("bankCode", "ALIPAY");//银行代码(支付宝填 ALIPAY)
        params.put("orderReason", "测试");//代付原因/用途
        params.put("requestIp", "159.138.86.177");//下单用户ip
        params.put("backNoticeUrl", notifyUrl);//通知结果地址


        //生成签名
        params.put("sign", getSign(params));

        //http请求并获取返回内容
        String response = HttpUtil.doHttpPost(gateway, DAIFU_PATH, params);
        final JSONObject objects = JSONObject.parseObject(response);

        if (objects == null) {
            System.out.println("代付失败");
            return;
        }

        try {
            final JSONObject bizObj = objects.getJSONObject("biz");
            System.out.println(bizObj.toJSONString());
        } catch (Exception e) {
            String msg = objects.containsKey("msg") ? "代付失败:" + objects.getString("msg") : "代付失败";
            System.out.println(msg);
        }
    }

    /**
     * 代付查单
     *
     * @see DaDongPay#query()
     */
    public void daifuQuery() {
        throw new RuntimeException("请参考支付查单");
    }

    /**
     * 代付回调验签
     *
     * @see DaDongPay#returnVerify(String)
     */
    public void daifuReturnVerify(String json) {
        throw new RuntimeException("请参考支付验签");
    }

    private String getSign(Map<String, Object> params) {
        //1. 进行字段排序,并清除无效字段
        final Map<String, Object> sortMapByKey = Utils.sortMapByKey(params);
        Utils.removeNullValue(sortMapByKey);

        //2. 将排序后的参数进行拼接:key1=value1&key2=value2
        final String originalSignStr = Utils.getUrlParamsByMap(sortMapByKey);
        //3. 最后拼接上密钥进行md5得到sign
        final String md5Beofre = originalSignStr + signKey;
        System.out.println("签名原串:" + md5Beofre);
        return DigestUtils.md5Hex(md5Beofre);
    }

    private String getCurrentTimeWithFormat() {
        final SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmss");
        fmt.setTimeZone(TimeZone.getTimeZone("GMT+8")); //必须北京时间，否则参数不通过
        return fmt.format(new Date());
    }

}
